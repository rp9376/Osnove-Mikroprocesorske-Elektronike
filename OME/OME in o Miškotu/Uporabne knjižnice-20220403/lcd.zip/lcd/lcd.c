/*
 * Grafični gonilnik za platformo MiŠKo3.
 * Vsebuje:
 *   - lcd.{c,h}                Inicializacija in osnovno upravljanje zaslona
 *   - lcd_ili9341.{c,h}        Strojni vmesniki za inicializacijo in nastavljanje
 *                              krmilnika Ili9341 prek STMovega pomnilniškega vmesnika FMC
 *   - lcd_ili9341_registers.h  Seznam ukazov iz podatkovnega lista krmilnika Ili9341
 *   - lcd_grafika.{c,h}        Bitni tabeli za opcijski `Intro' funkciji
 *
 * (C) 2022 Nejc Bertoncelj <nbertoncelj afna student.uni-lj.si>
 *
 * Deli povzeti po vmesniku platforme MiŠKo2
 * (C) 2015 Pirc, Jankovec, Matič et al, Fakulteta za elektrotehniko
 */

#include "lcd.h"

//! @brief Globalna struktura grafičnega vmesnika (dimenzije, pisava, barve ...)
UG_GUI gui;

/*!
 * @brief Nizkonivojska inicializacija zaslona
 * @internal
 */
static void LCD_IO_Init()
{
	LCD_RST_LOW();
	HAL_Delay(120);
	LCD_RST_HIGH();
	HAL_Delay(120);
}

/*!
 * @brief Izris posameznega piksla na zaslon
 * @param x x koordinata zaslona
 * @param y y koordinata zaslona
 * @param c podatek o barvi
 * @internal
 *
 * To funkcijo uporablja grafična knjižnica uGUI, z njo pa se lahko izrišejo vsi grafični elementi.
 * Ker je ta metoda počasna pri večjih površinah, imamo tudi strojno pospešene funkcije.
 */
static void UserPixelSetFunction(UG_S16 x, UG_S16 y, UG_COLOR c)
{
	// Izbor koordinat piksla
	ILI9341_SetDisplayWindow(x, y, 1, 1);

	// Zapis barve
	ILI9341_SendData((LCD_IO_Data_t *)&c, 1);
	//ILI9341_SendDataDMA((LCD_IO_Data_t *)&c, 1); -- nima vidnega učinka
}

/*!
 * @brief Strojno pospešen izris polnega pravokotnega polja
 * @param x x koordinata izhodišča
 * @param y y koordinata izhodišča
 * @param h višina polja
 * @param w širina polja
 * @param c podatek o barvi
 * @internal
 *
 * Funkcija izbere želeno območje, potem pa tolikokrat pošlje izbrano barvo,
 * kolikor slikovnih točk je potrebnih.
 */
static void LCD_FillRect(uint32_t x, uint32_t y, uint32_t w, uint32_t h, UG_COLOR c)
{
	uint32_t max_count   = ILI9341_GetParam(LCD_AREA);     /* Št. vseh pikslov     */
	uint32_t pixel_count = ((w + 1) - x) * ((h + 1) - y);  /* Dejansko št. pikslov */

	if(pixel_count > max_count)
		pixel_count = max_count;

	// Izbor koordinat piksla
	ILI9341_SetDisplayWindow(x, y, w, h);

	ILI9341_SendRepeatedData(c, pixel_count);
	//while (pixel_count) {
	//	LCD_IO_SendData((uint16_t *)&c, LCD_IO_DATA_WRITE_CYCLES);
	//	pixel_count--;
	//}
}

/*!
 * @brief Pospešena funkcija za ukaz `UG_FillFrame'
 * @param x x koordinata izhodišča
 * @param y y koordinata izhodišča
 * @param h višina polja
 * @param w širina polja
 * @param c podatek o barvi
 * @internal
 *
 * Funkcija je vezni člen med grafično knjižnico uGUI in našo implementacijo pospešenega
 * izrisa pravokotnega polja.
 */
static inline UG_RESULT _HW_FillFrame_(UG_S16 x, UG_S16 y, UG_S16 w, UG_S16 h, UG_COLOR c)
{
	LCD_FillRect(x, y, w, h, c);

	return UG_RESULT_OK;
}

/*!
 * @brief Glavna inicializacija zaslona
 *
 * Funkcija pripravi zaslon do stanja, v katerem lahko uporabnik koristi vse funkcije
 * grafične knjižnice uGUI.
 *
 * Inicializacija nastavi privzet barvni prostor (RGB565), orientacijo zaslona, vklopi osvetlitev,
 * zapolni zaslon s črno barvo in nastavi bel tekst na črni podlagi.
 * @note Za inicializacijo posameznih strojnih enot mora poskrbeti uporabnik (npr. FMC)
 */
void LCD_Init()
{
	// Resetiraj V/I linijo zaslona
	LCD_IO_Init();

	// Inicializiraj krmilnik Ili9341 v barvnem prostoru RBG565 in brez zasuka slike
	ILI9341_Init(ILI9341_COLORSPACE_RBG565, ILI9341_MISKO_ROTATE_0);
	ILI9341_DisplayOn();

	// Inicializiraj grafično knjižnico s funkcijo za risanje pikslov in gabariti zaslona
	UG_Init(&gui, UserPixelSetFunction, ILI9341_GetParam(LCD_WIDTH), ILI9341_GetParam(LCD_HEIGHT));
	UG_FontSelect(&FONT_8X12);
	UG_SetForecolor(C_WHITE);
	UG_SetBackcolor(C_BLACK);

	// Omogoči strojno pospešene funkcije   TODO se splača preostale?
	UG_DriverRegister(DRIVER_FILL_FRAME, (void *)_HW_FillFrame_);
	UG_DriverEnable(DRIVER_FILL_FRAME);

	LCD_ClearScreen();
	// Gornja funkcija se bo zaključila pred izbrisom celega zaslona, ker si FMC zapomni vse
	// ukaze in sporoči, da se je zaključil prenos, ne pa pošiljanje.
	// Brez zamika bo zaslon za trenutek utripnil belo. Prej:  HAL_Delay(25);
	ILI9341_WaitTransfer();
	LCD_SetBacklight(1);
}

/*!
 * @brief Vklopi/izklopi osvetlitev zaslona
 * @param state logična vrednost
 */
void LCD_SetBacklight(uint8_t state)
{
	if (state == 1)
		HAL_GPIO_WritePin(LCD_BKLT_GPIO_Port, LCD_BKLT_Pin, GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(LCD_BKLT_GPIO_Port, LCD_BKLT_Pin, GPIO_PIN_RESET);
}

/*!
 * @brief Počisti zaslon (prebarvaj s črno barvo)
 */
void LCD_ClearScreen()
{
	LCD_FillRect(0, 0, ILI9341_GetParam(LCD_WIDTH), ILI9341_GetParam(LCD_HEIGHT), C_BLACK);
}

/*!
 * @brief Prikaži in animiraj logotip `MIŠKO 3'
 *
 * Funkcija izriše logotip, vklopi LED diode, počaka 3 sekunde in izstopi.
 * @note Potrebujeta se datoteki `lcd_grafika.{c,h}'
 */
void LCD_Intro_LogoSlide()
{
	ILI9341_SetOrientation(ILI9341_MISKO_ROTATE_270); // Zaradi smeri izrisovanja
	ILI9341_InvertDisplay(1);
	ILI9341_SetDisplayWindow(80, 80, LOGO_X, LOGO_Y);

	for (uint32_t i = 0; i < LOGO_SIZE; i += 2) {
		ILI9341_SendData((LCD_IO_Data_t *)&img_logotip[i], 1);

		if (i % (LOGO_Y * 2) == 0)
			HAL_Delay(20);
	}
	ILI9341_InvertDisplay(0);

	GPIOF->BSRR = (uint32_t)(LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin);
	GPIOC->BSRR = (uint32_t)(LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin);
	HAL_Delay(3000);
	GPIOF->BRR = (uint32_t)(LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin);
	GPIOC->BRR = (uint32_t)(LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin);

	ILI9341_SetOrientation(ILI9341_MISKO_ROTATE_0);
}

/*!
 * @brief Izris grafike z napisom `Ni programa...'
 *
 * Funkcija, ki nadomesti pomanjkanje programa (vsaj glavna ideja je taka). Deluje v neskončni
 * zanki in nikoli ne izstopi.
 * @note Potrebujeta se datoteki `lcd_grafika.{c,h}'
 * @note Grafika zasede dobršen del pomnilnika!
 */
void LCD_Intro_NoProgramHalt()
{
	uint16_t stevec = 0;

	UG_FillFrame(0, 0, 320, 240, C_WHITE);
	UG_FontSelect(&FONT_12X16);
	UG_SetBackcolor(C_WHITE);
	ILI9341_SetDisplayWindow(2, 20, AMIGA_X, AMIGA_Y);

	ILI9341_SendData((LCD_IO_Data_t *)&img_ni_programa, AMIGA_SIZE);

	for (uint8_t casovnik = 0; casovnik < 15; casovnik++) {
		UG_SetForecolor(C_DIM_GRAY);
		UG_PutString(120, 180, "Ni programa...");
		HAL_Delay(1000);
		UG_SetForecolor(C_MAROON);
		UG_PutString(120, 180, "Ni programa...");
		HAL_Delay(1000);
	}

	for (;;) {
		UG_SetForecolor(C_DIM_GRAY);
		UG_PutString(120, 180, "Ni programa...");
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		UG_SetForecolor(C_MAROON);
		UG_PutString(120, 180, "Ni programa...");
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		HAL_Delay(100); ILI9341_ScrollScreen(stevec++, SCROLL_LEFT);
		if(stevec == 320)
			stevec = 0;
	}
}
