//! @file    lcd.h
//! @brief   Grafični gonilnik za platformo MiŠKo3
//! @author  nbert, februar-marec 2022
#ifndef LCD_H_
#define LCD_H_

#include "main.h"
#include "lcd_ili9341.h"
#include "lcd_grafika.h"
#include "UGUI/ugui.h"

/* RESET Pin mapping */
#define LCD_RESET_GPIO_PORT  GPIOD
#define LCD_RESET_GPIO_PIN   GPIO_PIN_3

/* TE Pin mapping */
#define LCD_TE_GPIO_PORT     GPIOC
#define LCD_TE_GPIO_PIN      GPIO_PIN_14
#define LCD_TE_GPIO_LINE     EXTI_LINE_14
#define LCD_TE_GPIO_IRQn     EXTI15_10_IRQn
extern EXTI_HandleTypeDef    hexti_lcd_te;
#define H_EXTI_14            hexti_lcd_te

/* Chip Reset macro definition */
#define LCD_RST_LOW()        WRITE_REG(GPIOD->BRR, GPIO_PIN_3)
#define LCD_RST_HIGH()       WRITE_REG(GPIOD->BSRR, GPIO_PIN_3)

/* Demo sličice */
#define LOGO_X    73
#define LOGO_Y    158
#define LOGO_SIZE (2 * LOGO_X * LOGO_Y)

#define AMIGA_X    200
#define AMIGA_Y    200
#define AMIGA_SIZE (AMIGA_X * AMIGA_Y)

void LCD_Init();
void LCD_SetBacklight(uint8_t state);
void LCD_ClearScreen();
void LCD_Intro_LogoSlide();
void LCD_Intro_NoProgramHalt();

#endif /* LCD_H_ */
