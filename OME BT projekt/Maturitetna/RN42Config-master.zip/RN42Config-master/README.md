# RN42Config
- Author: Evan Kale
- Email: evankale91@gmail.com
- Web: ISeeDeadPixel.com
- Blog: evankale.blogspot.ca
- YouTube: youtube.com/EvanKale91

See a demo video here:
https://youtu.be/UJaqHnPR-XE

- An Arduino dev tool.
- Establishes a software serial communication channel on digtal pins D2 and D3 at the baud rate of 9600.
